CREATE DATABASE MED_ON;
USE MED_ON;
CREATE TABLE Usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    tipo_usuario ENUM('Paciente', 'Médico', 'Admin') NOT NULL
);
CREATE TABLE Pacientes (
    id_paciente INT PRIMARY KEY,
    data_nascimento DATE NOT NULL,
    sexo ENUM('Masculino', 'Feminino', 'Outro'),
    telefone VARCHAR(15),
    endereco VARCHAR(255),
    FOREIGN KEY (id_paciente) REFERENCES Usuarios(id_usuario)
);
CREATE TABLE Medicos (
    id_medico INT PRIMARY KEY,
    especialidade VARCHAR(100) NOT NULL,
    crm VARCHAR(20) NOT NULL UNIQUE,
    experiencia_anos INT NOT NULL,
    FOREIGN KEY (id_medico) REFERENCES Usuarios(id_usuario)
);
CREATE TABLE Administradores (
    id_admin INT PRIMARY KEY,
    nivel_acesso ENUM('Baixo', 'Médio', 'Alto') NOT NULL,
    FOREIGN KEY (id_admin) REFERENCES Usuarios(id_usuario)
);
CREATE TABLE Consultas (
    id_consulta INT AUTO_INCREMENT PRIMARY KEY,
    id_paciente INT NOT NULL,
    id_medico INT NOT NULL,
    data_consulta DATETIME NOT NULL,
    status ENUM('Agendada', 'Realizada', 'Cancelada') NOT NULL,
    descricao TEXT,
    FOREIGN KEY (id_paciente) REFERENCES Pacientes(id_paciente),
    FOREIGN KEY (id_medico) REFERENCES Medicos(id_medico)
);
CREATE TABLE Prescricoes (
    id_prescricao INT AUTO_INCREMENT PRIMARY KEY,
    id_consulta INT NOT NULL,
    medicamentos TEXT NOT NULL,
    instrucoes TEXT NOT NULL,
    FOREIGN KEY (id_consulta) REFERENCES Consultas(id_consulta)
);
CREATE TABLE Pagamentos (
    id_pagamento INT AUTO_INCREMENT PRIMARY KEY,
    id_consulta INT NOT NULL,
    metodo_pagamento ENUM('Cartão', 'Boleto', 'Pix', 'Dinheiro') NOT NULL,
    valor DECIMAL(10, 2) NOT NULL,
    data_pagamento DATETIME NOT NULL,
    status ENUM('Pendente', 'Pago') NOT NULL,
    FOREIGN KEY (id_consulta) REFERENCES Consultas(id_consulta)
);
CREATE TABLE Feedbacks (
    id_feedback INT AUTO_INCREMENT PRIMARY KEY,
    id_consulta INT NOT NULL,
    id_paciente INT NOT NULL,
    comentario TEXT,
    avaliacao INT CHECK (avaliacao BETWEEN 1 AND 5),
    FOREIGN KEY (id_consulta) REFERENCES Consultas(id_consulta),
    FOREIGN KEY (id_paciente) REFERENCES Pacientes(id_paciente)
);
INSERT INTO Usuarios (nome, email, senha, tipo_usuario)
VALUES 
('João da Silva', 'joao.silva@gmail.com', 'senha123', 'Paciente'),
('Maria Souza', 'maria.souza@gmail.com', 'senha123', 'Paciente'),
('Dr. Pedro Almeida', 'pedro.almeida@gmail.com', 'senha123', 'Médico'),
('Dra. Ana Costa', 'ana.costa@gmail.com', 'senha123', 'Médico'),
('Admin Diogo', 'diogomamedio3@gmail.com', 'senha123', 'Admin');

INSERT INTO Pacientes (id_paciente, data_nascimento, sexo, telefone, endereco)
VALUES 
(1, '1990-05-15', 'Masculino', '123456789', 'Rua das Flores, 123'),
(2, '1985-10-20', 'Feminino', '987654321', 'Avenida Central, 456');

INSERT INTO Medicos (id_medico, especialidade, crm, experiencia_anos)
VALUES 
(3, 'Cardiologia', 'CRM12345', 10),
(4, 'Dermatologia', 'CRM67890', 8);

INSERT INTO Administradores (id_admin, nivel_acesso)
VALUES 
(5, 'Alto');

INSERT INTO Consultas (id_paciente, id_medico, data_consulta, status, descricao)
VALUES 
(1, 3, '2024-12-20 10:00:00', 'Agendada', 'Consulta inicial para avaliação cardiovascular.'),
(2, 4, '2024-12-22 14:30:00', 'Agendada', 'Consulta para tratamento de acne crônica.');

INSERT INTO Prescricoes (id_consulta, medicamentos, instrucoes)
VALUES 
(1, 'Aspirina 100mg', 'Tomar 1 comprimido ao dia após o almoço.'),
(2, 'Creme para acne', 'Aplicar à noite antes de dormir.');

INSERT INTO Pagamentos (id_consulta, metodo_pagamento, valor, data_pagamento, status)
VALUES 
(1, 'Cartão', 150.00, '2024-12-18 08:00:00', 'Pago'),
(2, 'Pix', 200.00, '2024-12-18 08:30:00', 'Pago');

INSERT INTO Feedbacks (id_consulta, id_paciente, comentario, avaliacao)
VALUES 
(1, 1, 'Atendimento excelente, médico muito atencioso.', 5),
(2, 2, 'Gostei do atendimento, mas estava travando.', 4);

select * from pacientes;
select * from usuarios;
select * from medicos;
select * from pagamentos;
select * from feedbacks;
select * from prescricoes;

#Quanto o adminstrador ganhou, já que ele fica com 10% dos pagamentos?
CREATE VIEW LucroTotal AS
SELECT 
    SUM(valor) AS lucro_total
FROM 
    Pagamentos
WHERE 
    status = 'Pago';
DELIMITER $$
CREATE FUNCTION GanhoAdministrador()
RETURNS DECIMAL(10, 2)
DETERMINISTIC
BEGIN
    DECLARE lucro DECIMAL(10, 2);
    DECLARE ganho DECIMAL(10, 2);
    SELECT lucro_total INTO lucro FROM LucroTotal;
    SET ganho = lucro * 0.10;

    RETURN ganho;
END$$
DELIMITER ;
SELECT GanhoAdministrador() AS ganho_administrador;

#QUEM O DR. PEDRO ATENDEU? 
SELECT 
    c.id_consulta, 
    u.nome AS paciente, 
    c.data_consulta, 
    c.status, 
    c.descricao
FROM 
    Consultas c
INNER JOIN 
    Pacientes p ON c.id_paciente = p.id_paciente
INNER JOIN 
    Usuarios u ON p.id_paciente = u.id_usuario
INNER JOIN 
    Medicos m ON c.id_medico = m.id_medico
WHERE 
    m.id_medico = (
        SELECT id_usuario 
        FROM Usuarios 
        WHERE nome = 'Dr. Pedro Almeida'
    );

#QUEM A DRa. ANA ATENDEU?
SELECT 
    c.id_consulta, 
    u.nome AS paciente, 
    c.data_consulta, 
    c.status, 
    c.descricao
FROM 
    Consultas c
INNER JOIN 
    Pacientes p ON c.id_paciente = p.id_paciente
INNER JOIN 
    Usuarios u ON p.id_paciente = u.id_usuario
INNER JOIN 
    Medicos m ON c.id_medico = m.id_medico
WHERE 
    m.id_medico = (
        SELECT id_usuario 
        FROM Usuarios 
        WHERE nome = 'Dra. Ana Costa'
    );
    
#QUANTOS ATENDIMENTOS DR. PEDRO FEZ E QUANTO E ELE FATUROU? 
SELECT 
    u.nome AS medico, 
    COUNT(c.id_consulta) AS total_atendimentos,
    SUM(pg.valor) * 0.90 AS faturamento_liquido
FROM 
    Consultas c
INNER JOIN 
    Medicos m ON c.id_medico = m.id_medico
INNER JOIN 
    Usuarios u ON m.id_medico = u.id_usuario
INNER JOIN 
    Pagamentos pg ON c.id_consulta = pg.id_consulta
WHERE 
    u.nome = 'Dr. Pedro Almeida'
    AND pg.status = 'Pago'
GROUP BY 
    u.nome;

#QUANTOS ATENDIMENTOS DRa. ANA FEZ E QUANTO ELA FATUROU?

SELECT 
    u.nome AS medico, 
    COUNT(c.id_consulta) AS total_atendimentos,
    SUM(pg.valor) * 0.90 AS faturamento_liquido
FROM 
    Consultas c
INNER JOIN 
    Medicos m ON c.id_medico = m.id_medico
INNER JOIN 
    Usuarios u ON m.id_medico = u.id_usuario
INNER JOIN 
    Pagamentos pg ON c.id_consulta = pg.id_consulta
WHERE 
    u.nome = 'Dra. Ana Costa'
    AND pg.status = 'Pago'
GROUP BY 
    u.nome;


